#include <iostream>
#include <string>
using namespace std;


int main(int argc, char *argc[]){
	int k;
	//TO DO
}
